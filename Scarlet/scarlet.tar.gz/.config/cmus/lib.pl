/media/addy/Toshiba/musics/Other Black Metal/Advent Sorrow - Pestilence Shall Come.flac
/media/addy/Toshiba/musics/Arkona/Lunaris/Arkona - Droga Do Ocalenia.flac
/media/addy/Toshiba/musics/Arkona/Lunaris/Arkona - Ziemia.flac
/media/addy/Toshiba/musics/Arkona/Lunaris/Arkona - Śmierć I Odrodzenie.flac
/media/addy/Toshiba/musics/Arkona/Lunaris/Arkona - Nie Dla Mnie Litość.flac
/media/addy/Toshiba/musics/Arkona/Lunaris/Arkona - Lśnienie.flac
/media/addy/Toshiba/musics/Arkona/Lunaris/Arkona - Lunaris.flac
/media/addy/Toshiba/musics/Arkona/Age of Capricorn/Arkona - Stellar Inferno.flac
/media/addy/Toshiba/musics/Arkona/Age of Capricorn/Arkona - Alone Among Wolves.flac
/media/addy/Toshiba/musics/Arkona/Age of Capricorn/Arkona - Age of Capricorn.flac
/media/addy/Toshiba/musics/Arkona/Age of Capricorn/Arkona - Deathskull Mystherium.flac
/media/addy/Toshiba/musics/Arkona/Age of Capricorn/Arkona - Towards the Dark.flac
/media/addy/Toshiba/musics/Arkona/Age of Capricorn/Arkona - Grand Manifest of Death.flac
/media/addy/Toshiba/musics/Batushka/Litourgiya/Batushka - Yekteniya I  Ochishcheniye.flac
/media/addy/Toshiba/musics/Batushka/Litourgiya/Batushka - Yekteniya II  Blagosloveniye.flac
/media/addy/Toshiba/musics/Batushka/Litourgiya/Batushka - Yekteniya III  Premudrost'.flac
/media/addy/Toshiba/musics/Batushka/Litourgiya/Batushka - Yekteniya IV  Milost'.flac
/media/addy/Toshiba/musics/Batushka/Litourgiya/Batushka - Yekteniya V  Svyatyy Vkhod.flac
/media/addy/Toshiba/musics/Batushka/Litourgiya/Batushka - Yekteniya VI  Upovanie.flac
/media/addy/Toshiba/musics/Batushka/Litourgiya/Batushka - Yekteniya VII  Istina.flac
/media/addy/Toshiba/musics/Batushka/Litourgiya/Batushka - Yekteniya VIII  Spasenie.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Wozglas.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Dziewiatyj Czas.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Wieczernia.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Powieczerje.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Polunosznica.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Utrenia.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Pierwyj Czas.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Tretij Czas.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Szestoj Czas.flac
/media/addy/Toshiba/musics/Batushka/Hospodi/Batushka - Liturgiya.flac
/media/addy/Toshiba/musics/Other Black Metal/Behemoth - Ora Pro Nobis Lucifer.flac
/media/addy/Toshiba/musics/Other Black Metal/Behemoth - Ecclesia Diabolica Catholica.flac
/media/addy/Toshiba/musics/Other Black Metal/Celestia - Phoenemenae of Creation.m4a
/media/addy/Toshiba/musics/Gramary/Death Inbound/Gramary - Dead and Gone.flac
/media/addy/Toshiba/musics/Gramary/Death Inbound/Gramary - Hanged to the Highest Tree.flac
/media/addy/Toshiba/musics/Gramary/Death Inbound/Gramary - Only Blackness.flac
/media/addy/Toshiba/musics/Gramary/Death Inbound/Gramary - To Whatever End.flac
/media/addy/Toshiba/musics/Gramary/Death Inbound/Gramary - Black Wings Unfurling.flac
/media/addy/Toshiba/musics/Gramary/Death Inbound/Gramary - 10 000 Screams.flac
/media/addy/Toshiba/musics/Gramary/Death Inbound/Gramary - I Raise My Thousand Swords.flac
/media/addy/Toshiba/musics/Gramary/Death Inbound/Gramary - -.flac
/media/addy/Toshiba/musics/Grima/Tales of the Enchanted Woods/Grima - The Sentry Peak.ogg
/media/addy/Toshiba/musics/Grima/Tales of the Enchanted Woods/Grima - The Moon and It's Shadows.ogg
/media/addy/Toshiba/musics/Grima/Tales of the Enchanted Woods/Grima - Ritual.ogg
/media/addy/Toshiba/musics/Grima/Tales of the Enchanted Woods/Grima - Wolfberry.ogg
/media/addy/Toshiba/musics/Grima/Tales of the Enchanted Woods/Grima - Never Get off the Trail.ogg
/media/addy/Toshiba/musics/Grima/Tales of the Enchanted Woods/Grima - The Grief.ogg
/media/addy/Toshiba/musics/Grima/Tales of the Enchanted Woods/Grima - The Shepherds of the Mountains and Plains.ogg
/media/addy/Toshiba/musics/Grima/Tales of the Enchanted Woods/Grima - The Sorrowbringer.ogg
/media/addy/Toshiba/musics/Grima/Will of the Primordial/Grima - Siberian Sorrow.flac
/media/addy/Toshiba/musics/Grima/Will of the Primordial/Grima - The Shrouded in Darkness.flac
/media/addy/Toshiba/musics/Grima/Will of the Primordial/Grima - Leshiy.flac
/media/addy/Toshiba/musics/Grima/Will of the Primordial/Grima - Spiritual Emptiness.flac
/media/addy/Toshiba/musics/Grima/Will of the Primordial/Grima - Enisey.flac
/media/addy/Toshiba/musics/Grima/Will of the Primordial/Grima - Blizzard.flac
/media/addy/Toshiba/musics/Grima/Will of the Primordial/Grima - Howl at Night.flac
/media/addy/Toshiba/musics/Grima/Will of the Primordial/Grima - Rest in the Snow.flac
/media/addy/Toshiba/musics/Grima/Rotting Garden/Grima - Cedar and Owls.flac
/media/addy/Toshiba/musics/Grima/Rotting Garden/Grima - Mourning Comes at Sunset.flac
/media/addy/Toshiba/musics/Grima/Rotting Garden/Grima - At the Foot of the Red Mountains.flac
/media/addy/Toshiba/musics/Grima/Rotting Garden/Grima - Old Oak.flac
/media/addy/Toshiba/musics/Grima/Rotting Garden/Grima - Rotting Garden.flac
/media/addy/Toshiba/musics/Grima/Rotting Garden/Grima - Grom.flac
/media/addy/Toshiba/musics/Grima/Rotting Garden/Grima - Devotion to Lord.flac
/media/addy/Toshiba/musics/Grima/Frostbitten/Grima - Gloomy Heart of the Coldest Land.flac
/media/addy/Toshiba/musics/Grima/Frostbitten/Grima - Giant’s Eternal Sleep.flac
/media/addy/Toshiba/musics/Grima/Frostbitten/Grima - Into the Twilight.flac
/media/addy/Toshiba/musics/Grima/Frostbitten/Grima - Hunger God.flac
/media/addy/Toshiba/musics/Grima/Frostbitten/Grima - Moonspell and Grief.flac
/media/addy/Toshiba/musics/Grima/Frostbitten/Grima - Winter Morning Tower.flac
/media/addy/Toshiba/musics/Grima/Frostbitten/Grima - Mana.flac
/media/addy/Toshiba/musics/Other Black Metal/Highland - A Seed Once Spread.flac
/media/addy/Toshiba/musics/Other Black Metal/Imperium Dekadenz - Volcano.ogg
/media/addy/Toshiba/musics/Other Black Metal/Life is Pain - Negativity.flac
/media/addy/Toshiba/musics/Magoth/Anti Terrestrial Black Metal/Magoth - Cleansing of the Ancient Spirits.flac
/media/addy/Toshiba/musics/Magoth/Anti Terrestrial Black Metal/Magoth - Indoctrination War.flac
/media/addy/Toshiba/musics/Magoth/Anti Terrestrial Black Metal/Magoth - Der Toten Gesang.flac
/media/addy/Toshiba/musics/Magoth/Anti Terrestrial Black Metal/Magoth - Mental Fortress.flac
/media/addy/Toshiba/musics/Magoth/Anti Terrestrial Black Metal/Magoth - Thorns.flac
/media/addy/Toshiba/musics/Magoth/Anti Terrestrial Black Metal/Magoth - Sola Scriptura.flac
/media/addy/Toshiba/musics/Magoth/Anti Terrestrial Black Metal/Magoth - Sheol.flac
/media/addy/Toshiba/musics/Magoth/Anti Terrestrial Black Metal/Magoth - Requiem Deus.flac
/media/addy/Toshiba/musics/Magoth/Anti Terrestrial Black Metal/Magoth - Cosmic Termination.flac
/media/addy/Toshiba/musics/Magoth/Magoth - Declaring Eschaton.flac
/media/addy/Toshiba/musics/Mourning by Morning/A Step Away From Light A Step Into Abyss/Mourning by Morning - A Step Away From Light.flac
/media/addy/Toshiba/musics/Mourning by Morning/A Step Away From Light A Step Into Abyss/Mourning by Morning - Bastard Sanctuary.flac
/media/addy/Toshiba/musics/Mourning by Morning/A Step Away From Light A Step Into Abyss/Mourning by Morning - I Am But A Shadow Beneath You.flac
/media/addy/Toshiba/musics/Mourning by Morning/A Step Away From Light A Step Into Abyss/Mourning by Morning - Onward To My Descent.flac
/media/addy/Toshiba/musics/Mourning by Morning/A Step Away From Light A Step Into Abyss/Mourning by Morning - As I Bleed.flac
/media/addy/Toshiba/musics/Mourning by Morning/A Step Away From Light A Step Into Abyss/Mourning by Morning - The Night Is Fleeting.flac
/media/addy/Toshiba/musics/Mourning by Morning/A Step Away From Light A Step Into Abyss/Mourning by Morning - Beyond The Gates.flac
/media/addy/Toshiba/musics/Mourning by Morning/A Step Away From Light A Step Into Abyss/Mourning by Morning - A Step Into Abyss.flac
/media/addy/Toshiba/musics/Other Black Metal/Mourning Forest - The Cave.m4a
/media/addy/Toshiba/musics/Other Black Metal/Nyrst - Orsök.flac
/media/addy/Toshiba/musics/Other Black Metal/Uada - Black Autumn, White Spring.flac
